'use strict';

function BinarioADecimal(num) {}

function DecimalABinario(num) {}

module.exports = {
   BinarioADecimal,
   DecimalABinario,
};
